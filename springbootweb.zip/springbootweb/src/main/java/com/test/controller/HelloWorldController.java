package com.test.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class HelloWorldController {
	
	@RequestMapping("/submited")
	public String submited() {
		return "Hello Rajesh submitted";
	}
	
	@RequestMapping("/welcome")
	public String hello(ModelMap model) {
		return "welcome";
	}
}
