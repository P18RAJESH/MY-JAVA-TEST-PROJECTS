package com.test.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldController {
	
	@RequestMapping("/submited")
	public String submited() {
		return "Hello Rajesh submitted";
	}
	
	@RequestMapping("/welcome")
	public String hello() {
		return "Hello Rajesh welcome";
	}
}
