package com.test.webservice;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import org.springframework.stereotype.Service;
import org.tmatesoft.svn.core.SVNException;

import com.test.model.TagDetails;
import com.test.svnservice.SyncReporterToolV5;
import com.test.svnservice.UtilityCommonV5;

@Service
public class LoginService {
	public boolean generateReport(TagDetails tagObj) {
		SyncReporterToolV5 sync = new SyncReporterToolV5();
		return sync.GenerateReport(tagObj);
	}
	
	public String[] getTags() {
		UtilityCommonV5 util =new UtilityCommonV5();
		String[] tagsList=util.getTags();
		return tagsList;
	}
	
	public ByteArrayInputStream getDownloadReport(TagDetails tagObj) {
		UtilityCommonV5 util =new UtilityCommonV5();
		ByteArrayInputStream downloadFile = null;
		try {
			downloadFile = util.downloadXLSXFile(tagObj);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SVNException e) {
			e.printStackTrace();
		}
		return downloadFile;
	}
	
	
}
