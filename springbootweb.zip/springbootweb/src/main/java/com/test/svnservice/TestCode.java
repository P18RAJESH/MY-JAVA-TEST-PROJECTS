package com.test.svnservice;

import java.util.ArrayList;
import java.util.List;

import javax.mail.Message;
import javax.mail.internet.InternetAddress;

public class TestCode {

	public static void main1(String[] args) {
		SyncReporterToolV5 sync = new SyncReporterToolV5();

		UtilityCommonV5 util = new UtilityCommonV5();
		/*String dev4Url="https://AE1BWDSSSVN01.ctdssaws.local/svn/CTIE/UAT-Tags/WP-16.2.0-2.0-20210616/"; // Parent
		String dev4Urlhas="/UAT-Tags/WP-16.2";
		String dev4Urlsheet="16.2";
		
		String dev3Url="https://AE1BWDSSSVN01.ctdssaws.local/svn/CTIE/UAT-Tags/WP-17.0.0-10.0-20210623/"; // Child
		String dev3Urlhas="/UAT-Tags/WP-17.0";
		String dev3Urlsheet="17.0";*/
		//String test ="/UAT-Tags/WP-17.0";
		//System.out.println(util.getTags());
		//System.out.println(test.substring(util.ordinalIndexOf(test, "-", 2)+1));
		//System.out.println(dev3Url.substring(util.ordinalIndexOf(dev3Url, "/", 5)).substring(0,util.ordinalIndexOf(dev3Url.substring(util.ordinalIndexOf(dev3Url, "/", 5)), ".", 2)));
		//sync.GenerateReport(dev4Url,dev4Urlhas,dev4Urlsheet,dev3Url,dev3Urlhas,dev3Urlsheet);
		
		//List<String> userIds = new ArrayList<String>();
		
		//util.sendWithAttachment(dev3Urlsheet, dev4Urlsheet, userIds);
		
		String allUser ="skrishnamurthi,anpesala,savinnakota,rakaran,parthpatel8,avintiwari,rgayam,chiraggupta9,arusrinivasan,anpv,parmohan,mnarendraharsha,szareen,sankdesai,madaanc,pmedatati,schamling,skrishnamurthi,anpesala,savinnakota,rakaran,parthpatel8,avintiwari,rgayam,chiraggupta9,arusrinivasan,anpv,parmohan,mnarendraharsha,szareen,sankdesai,madaanc,pmedatati,schamling,shrums,skrishnamurthi,anpesala,savinnakota,parthpatel8,avintiwari,mnarendraharsha,parmohan,szareen,sankdesai,anpv,madaanc,pmedatati,schamling,shrums,anpv,skrishnamurthi,parthpatel8,schamling,anpv,pmedatati,avintiwari,skrishnamurthi,parthpatel8,schamling,shrums,anpv,pmedatati,avintiwari,kpusa";
		String usiUser ="shariharant,cskumar,shrums,anaduvinahalli,cnandi,mputturu,nashankar,pranshetty,hsinha,bosubramani,kvijayajyothi,muchawla,pradang,shwjaiswal,gajindal,kkhattri,haverma,sahmedkhan,aakshitha,bkandakatla,sulenka,cmadaan,lmantri,pmedatati,prachimishra,parmohan,gnagapavan,mnarendraharsha,anpv,tpanyala,rpappla,aprasoon,kpusa,brajarshi,kalvreddy,pshanmukham,csivapriya,bsuneetha,avintiwari,puppunda,savinnakota,szareen,rasar,sgodse,yogejain,mkavatkar,ppriyamvada,vimraina,sirajguru";
		String[] usiUserIds = usiUser.split(",");
		String[] allUserIds = allUser.split(",");
		List<String> UsiauthorIds = new ArrayList<String>();
		for (String to : usiUserIds) {
			UsiauthorIds.add(to);
		}
		for (String to : allUserIds) {
			if(UsiauthorIds.contains(to))
			{
				System.out.print(to.concat("@deloitte.com")+ ",");
			}
		}
		System.out.println("");
		
	}

}
