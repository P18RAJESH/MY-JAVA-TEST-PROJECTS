package com.test.svnservice;

import java.awt.Color;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;


import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;


import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.extensions.XSSFCellBorder;
import org.springframework.util.ResourceUtils;
import org.tmatesoft.svn.core.SVNException;
import com.test.model.ChangeLogEntry;
import com.test.model.ChangePathDetails;
import com.test.model.TagDetails;

public class UtilityCommonV5 {

	public List<String> writeXLSXFile(List<ChangeLogEntry> dev04ChangeLog, List<ChangeLogEntry> dev03ChangeLog,
			List<ChangeLogEntry> missingFilesInDev03From04Log,TagDetails tObj) throws IOException, SVNException {

		
		String dev4Urlsheet = tObj.getPfilename();
		String dev3Urlsheet=tObj.getCfilename();
		
		//USI USER ONLY
		String usiUser ="shariharant,cskumar,shrums,anaduvinahalli,cnandi,mputturu,nashankar,pranshetty,hsinha,bosubramani,kvijayajyothi,muchawla,pradang,shwjaiswal,gajindal,kkhattri,haverma,sahmedkhan,aakshitha,bkandakatla,sulenka,cmadaan,lmantri,pmedatati,prachimishra,parmohan,gnagapavan,mnarendraharsha,anpv,tpanyala,rpappla,aprasoon,kpusa,brajarshi,kalvreddy,pshanmukham,csivapriya,bsuneetha,avintiwari,puppunda,savinnakota,szareen,rasar,sgodse,yogejain,mkavatkar,ppriyamvada,vimraina,sirajguru";
		String[] usiUserIds = usiUser.split(",");
		
		List<String> UsiauthorIds = new ArrayList<String>();
		for (String to : usiUserIds) {
			UsiauthorIds.add(to);
		}
		
		String sheet3Name = "In" + dev4Urlsheet + "NotIn" + dev3Urlsheet;
		
		List<String> userIds = new ArrayList<String>();
		Color LIGHT_GREEN = new Color(146, 208, 80);
		Color LIGHT_RED = new Color(255, 85, 85);
		Color BLUE = new Color(0, 112, 192);

		java.util.Date date = new java.util.Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		String directory = Constants.getOutputFolder();
		String excelFileNametemp = directory + "Checkin_Report_" + dev4Urlsheet + "-" + dev3Urlsheet
				+ "On";
		String excelFileName = excelFileNametemp + sdf.format(date) + ".xlsx";
		String sheet1Name = dev3Urlsheet + "_Change_Log";
		String sheet2Name = dev4Urlsheet + "_Change_Log";
		String sheet03Name = sheet3Name;

		List<ChangeLogEntry> sheet1Files = new ArrayList<ChangeLogEntry>();
		List<ChangeLogEntry> sheet2Files = new ArrayList<ChangeLogEntry>();
		List<ChangeLogEntry> sheet3Files = new ArrayList<ChangeLogEntry>();

		sheet1Files = dev03ChangeLog;
		sheet2Files = dev04ChangeLog;
		sheet3Files = missingFilesInDev03From04Log;

		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet1 = wb.createSheet(sheet1Name);
		XSSFSheet sheet2 = wb.createSheet(sheet2Name);
		XSSFSheet sheet3 = wb.createSheet(sheet03Name);

		XSSFCellStyle style = wb.createCellStyle();
		style.setBorderColor(XSSFCellBorder.BorderSide.TOP, new XSSFColor(java.awt.Color.BLACK));
		style.setBorderColor(XSSFCellBorder.BorderSide.BOTTOM, new XSSFColor(java.awt.Color.BLACK));
		style.setBorderColor(XSSFCellBorder.BorderSide.LEFT, new XSSFColor(java.awt.Color.BLACK));
		style.setBorderColor(XSSFCellBorder.BorderSide.RIGHT, new XSSFColor(java.awt.Color.BLACK));
		style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		style.setBorderTop(XSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		style.setBorderRight(XSSFCellStyle.BORDER_THIN);

		sheet3.setTabColor(2);

		XSSFRow headerrow1 = sheet1.createRow(0);
		XSSFRow headerrow2 = sheet2.createRow(0);
		XSSFRow headerrow3 = sheet3.createRow(0);

		// Green background
		XSSFCellStyle style1 = wb.createCellStyle();
		style1.setFillForegroundColor(new XSSFColor(LIGHT_GREEN));
		style1.setFillPattern(CellStyle.SOLID_FOREGROUND);
		style1.setBorderColor(XSSFCellBorder.BorderSide.TOP, new XSSFColor(java.awt.Color.BLACK));
		style1.setBorderColor(XSSFCellBorder.BorderSide.BOTTOM, new XSSFColor(java.awt.Color.BLACK));
		style1.setBorderColor(XSSFCellBorder.BorderSide.LEFT, new XSSFColor(java.awt.Color.BLACK));
		style1.setBorderColor(XSSFCellBorder.BorderSide.RIGHT, new XSSFColor(java.awt.Color.BLACK));
		style1.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		style1.setBorderTop(XSSFCellStyle.BORDER_THIN);
		style1.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		style1.setBorderRight(XSSFCellStyle.BORDER_THIN);

		XSSFCell headercell1 = headerrow1.createCell(0);
		headercell1.setCellValue("Developer Id");
		headercell1.setCellStyle(style1);
		headercell1 = headerrow1.createCell(1);
		headercell1.setCellValue("Time Of Check-in");
		headercell1.setCellStyle(style1);
		headercell1 = headerrow1.createCell(2);
		headercell1.setCellValue("JIRA ID");
		headercell1.setCellStyle(style1);
		headercell1 = headerrow1.createCell(3);
		headercell1.setCellValue("Comment");
		headercell1.setCellStyle(style1);
		headercell1 = headerrow1.createCell(4);
		headercell1.setCellValue("Action performed  -->  File(s) changed");
		headercell1.setCellStyle(style1);

		sheet1.setAutoFilter(CellRangeAddress.valueOf("A1:E1"));

		XSSFCellStyle style2 = wb.createCellStyle();
		style2.setFillForegroundColor(new XSSFColor(java.awt.Color.ORANGE));
		style2.setFillPattern(CellStyle.SOLID_FOREGROUND);
		style2.setBorderColor(XSSFCellBorder.BorderSide.TOP, new XSSFColor(java.awt.Color.BLACK));
		style2.setBorderColor(XSSFCellBorder.BorderSide.BOTTOM, new XSSFColor(java.awt.Color.BLACK));
		style2.setBorderColor(XSSFCellBorder.BorderSide.LEFT, new XSSFColor(java.awt.Color.BLACK));
		style2.setBorderColor(XSSFCellBorder.BorderSide.RIGHT, new XSSFColor(java.awt.Color.BLACK));
		style2.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		style2.setBorderTop(XSSFCellStyle.BORDER_THIN);
		style2.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		style2.setBorderRight(XSSFCellStyle.BORDER_THIN);

		XSSFCell headercell2 = headerrow2.createCell(0);
		headercell2.setCellValue("Developer Id");
		headercell2.setCellStyle(style2);
		headercell2 = headerrow2.createCell(1);
		headercell2.setCellValue("Time Of Check-in");
		headercell2.setCellStyle(style2);
		headercell2 = headerrow2.createCell(2);
		headercell2.setCellValue("JIRA ID");
		headercell2.setCellStyle(style2);
		headercell2 = headerrow2.createCell(3);
		headercell2.setCellValue("Comment");
		headercell2.setCellStyle(style2);
		headercell2 = headerrow2.createCell(4);
		headercell2.setCellValue("Action performed  -->  File(s) changed");
		headercell2.setCellStyle(style2);

		sheet2.setAutoFilter(CellRangeAddress.valueOf("A1:G1"));
/*
		wb.getSheetAt(3).protectSheet("Deloitte");
		wb.setSheetHidden(3, HSSFWorkbook.SHEET_STATE_VERY_HIDDEN);*/

		XSSFCellStyle style3 = wb.createCellStyle();
		Font font3 = wb.createFont();
		((XSSFFont) font3).setColor(new XSSFColor(java.awt.Color.WHITE));

		style3.setFillForegroundColor(new XSSFColor(BLUE));
		style3.setFont(font3);
		style3.setFillPattern(CellStyle.SOLID_FOREGROUND);
		style3.setBorderColor(XSSFCellBorder.BorderSide.TOP, new XSSFColor(java.awt.Color.BLACK));
		style3.setBorderColor(XSSFCellBorder.BorderSide.BOTTOM, new XSSFColor(java.awt.Color.BLACK));
		style3.setBorderColor(XSSFCellBorder.BorderSide.LEFT, new XSSFColor(java.awt.Color.BLACK));
		style3.setBorderColor(XSSFCellBorder.BorderSide.RIGHT, new XSSFColor(java.awt.Color.BLACK));
		style3.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		style3.setBorderTop(XSSFCellStyle.BORDER_THIN);
		style3.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		style3.setBorderRight(XSSFCellStyle.BORDER_THIN);

		XSSFCell headercell3 = headerrow3.createCell(0);
		headercell3.setCellValue("Developer Id");
		headercell3.setCellStyle(style3);
		headercell3 = headerrow3.createCell(1);
		headercell3.setCellValue("Time Of Check-in");
		headercell3.setCellStyle(style3);
		headercell3 = headerrow3.createCell(2);
		headercell3.setCellValue("JIRA ID");
		headercell3.setCellStyle(style3);
		headercell3 = headerrow3.createCell(3);
		headercell3.setCellValue("Comment");
		headercell3.setCellStyle(style3);
		headercell3 = headerrow3.createCell(4);
		headercell3.setCellValue("Action performed  -->  File(s) changed");
		headercell3.setCellStyle(style3);
		sheet3.setAutoFilter(CellRangeAddress.valueOf("A1:E1"));

		int r = 1;
		for (Iterator<ChangeLogEntry> iterator = sheet1Files.iterator(); iterator.hasNext();) {
			ChangeLogEntry rowLog = (ChangeLogEntry) iterator.next();
			XSSFRow row = sheet1.createRow(r);
			XSSFCell cell;

			List<ChangePathDetails> changePathDetailsList = rowLog.getChangePathDetails();
			for (Iterator<ChangePathDetails> iterator2 = changePathDetailsList.iterator(); iterator2.hasNext();) {
				cell = row.createCell(0);
				cell.setCellValue(rowLog.getAuthor());
				cell.setCellStyle(style);
				cell = row.createCell(1);
				cell.setCellValue(rowLog.getCheckinDate().toString());
				cell.setCellStyle(style);
				cell = row.createCell(2);
				cell.setCellValue(rowLog.getJiraId());
				cell.setCellStyle(style);
				cell = row.createCell(3);
				cell.setCellValue(rowLog.getMessage());
				cell.setCellStyle(style);
				cell = row.createCell(4);
				ChangePathDetails changePathDetails = (ChangePathDetails) iterator2.next();
				cell.setCellValue(changePathDetails.getAction() + " --> " + changePathDetails.getRelativePath());
				cell.setCellStyle(style);
				r++;
				row = sheet1.createRow(r);
			}

		}

		sheet1.autoSizeColumn(0);
		sheet1.autoSizeColumn(1);
		sheet1.autoSizeColumn(2);
		sheet1.autoSizeColumn(3);
		sheet1.autoSizeColumn(4);

		XSSFCellStyle errorStyle = wb.createCellStyle();
		errorStyle.setFillForegroundColor(new XSSFColor(LIGHT_RED));
		errorStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		errorStyle.setBorderColor(XSSFCellBorder.BorderSide.TOP, new XSSFColor(java.awt.Color.BLACK));
		errorStyle.setBorderColor(XSSFCellBorder.BorderSide.BOTTOM, new XSSFColor(java.awt.Color.BLACK));
		errorStyle.setBorderColor(XSSFCellBorder.BorderSide.LEFT, new XSSFColor(java.awt.Color.BLACK));
		errorStyle.setBorderColor(XSSFCellBorder.BorderSide.RIGHT, new XSSFColor(java.awt.Color.BLACK));
		errorStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		errorStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		errorStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		errorStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);

		r = 1;
		for (Iterator<ChangeLogEntry> iterator = sheet2Files.iterator(); iterator.hasNext();) {
			ChangeLogEntry rowLog = (ChangeLogEntry) iterator.next();
			XSSFRow row = sheet2.createRow(r);
			XSSFCell cell;

			List<ChangePathDetails> changePathDetailsList = rowLog.getChangePathDetails();
			for (Iterator<ChangePathDetails> iterator2 = changePathDetailsList.iterator(); iterator2.hasNext();) {
				cell = row.createCell(0);
				cell.setCellValue(rowLog.getAuthor());
				cell.setCellStyle(style);
				cell = row.createCell(1);
				cell.setCellValue(rowLog.getCheckinDate().toString());
				cell.setCellStyle(style);
				cell = row.createCell(2);
				cell.setCellValue(rowLog.getJiraId());
				cell.setCellStyle(style);
				cell = row.createCell(3);
				String rtcID = rowLog.getMessage();
				cell.setCellValue(rtcID);
				cell.setCellStyle(style);
				cell = row.createCell(4);
				ChangePathDetails changePathDetails = (ChangePathDetails) iterator2.next();
				cell.setCellValue(changePathDetails.getAction() + " --> " + changePathDetails.getRelativePath());
				cell.setCellStyle(style);
				r++;
				row = sheet2.createRow(r);
			}

		}

		sheet2.autoSizeColumn(0);
		sheet2.autoSizeColumn(1);
		sheet2.autoSizeColumn(2);
		sheet2.autoSizeColumn(3);
		sheet2.autoSizeColumn(4);
		sheet2.autoSizeColumn(5);
		sheet2.autoSizeColumn(6);

		r = 1;
		for (Iterator<ChangeLogEntry> iterator = sheet3Files.iterator(); iterator.hasNext();) {
			ChangeLogEntry rowLog = (ChangeLogEntry) iterator.next();
			XSSFRow row = sheet3.createRow(r);
			XSSFCell cell;
			List<ChangePathDetails> changePathDetailsList = rowLog.getChangePathDetails();
			for (Iterator<ChangePathDetails> iterator2 = changePathDetailsList.iterator(); iterator2.hasNext();) {
				cell = row.createCell(0);
				cell.setCellValue(rowLog.getAuthor());

				String userName = rowLog.getAuthor().concat("@deloitte.com");
				if (!userIds.contains(userName) && UsiauthorIds.contains(rowLog.getAuthor())) {
					userIds.add(userName);
				}
				cell.setCellStyle(style);
				cell = row.createCell(1);
				cell.setCellValue(rowLog.getCheckinDate().toString());
				cell.setCellStyle(style);
				cell = row.createCell(2);
				cell.setCellValue(rowLog.getJiraId());
				cell.setCellStyle(style);
				cell = row.createCell(3);
				String rtcID = rowLog.getRtcId();
				cell.setCellValue(rtcID);
				cell.setCellStyle(style);
				cell = row.createCell(4);
				ChangePathDetails changePathDetails = (ChangePathDetails) iterator2.next();
				cell.setCellValue(changePathDetails.getAction() + " --> " + changePathDetails.getRelativePath());
				cell.setCellStyle(style);
				r++;
				row = sheet3.createRow(r);
			}
		}

		sheet3.autoSizeColumn(0);
		sheet3.autoSizeColumn(1);
		sheet3.autoSizeColumn(2);
		sheet3.autoSizeColumn(3);
		sheet3.autoSizeColumn(4);
		sheet3.autoSizeColumn(5);
		sheet3.autoSizeColumn(6);

		FileOutputStream fileOut = new FileOutputStream(excelFileName);
		wb.write(fileOut);
		fileOut.flush();
		fileOut.close();
		wb.close();
		System.out.println(userIds.toString());
		return userIds;
	}

	public  ByteArrayInputStream downloadXLSXFile(TagDetails tObj) throws IOException, SVNException {
		
		java.util.Date date = new java.util.Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String dev4Urlsheet = tObj.getPfilename();
		String dev3Urlsheet=tObj.getCfilename();

		String directory = Constants.getOutputFolder();
		String excelFileNametemp = directory + "Checkin_Report_" + dev4Urlsheet + "-" + dev3Urlsheet
				+ "On";
		String excelFileName = excelFileNametemp + sdf.format(date) + ".xlsx";
		
		String result = readFile(excelFileName, StandardCharsets.UTF_8);

		ByteArrayInputStream is = new ByteArrayInputStream(result.getBytes("UTF-8"));
		return is;
		
	}
	public void sendWithAttachment(String dev3Urlsheet, String dev4Urlsheet, List<String> userIds,String emailCC) {
		try {
			String subject = Constants.getProperties().getString("emailSubject").toString();
			String emailFrom = "donotreply.deloitte@gmail.com";

			String emailTo = "";
			//String emailCC = Constants.getProperties().getString("mergeReportCC").toString();
			String emailTxt2 = Constants.getProperties().getString("emailText2Merge").toString() + dev4Urlsheet + " tag but not in "
					+ dev3Urlsheet + " tag.";
			String emailTxt1 = Constants.getProperties().getString("emailText1Merge").toString();
			String emailFileName = Constants.getProperties().getString("mergeReportFileName").toString();

			Date date = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

			String directory = Constants.getOutputFolder();
			String excelFileNametemp = directory + "Checkin_Report_" + dev4Urlsheet + "-" + dev3Urlsheet
					+ "On";
			String excelFileName = excelFileNametemp + sdf.format(date) + ".xlsx";

			String host = "smtp.gmail.com";
			String port = "465";
			final String smtpUsername = "donotreply.deloitte3@gmail.com";
			final String smtpPassword = "Deloitte123";
			Properties props = new Properties();
			   props.put("mail.smtp.auth", "true");
			   props.put("mail.smtp.starttls.enable", "true");
			   props.put("mail.smtp.host", "smtp.gmail.com");
			   props.put("mail.smtp.port", "587");
			emailTo=userIds.toString().replaceAll("\\[|\\]", "");
			String[] recipients = emailTo.split(",");
			System.out.println("Users \n" + userIds.toString().replaceAll("\\[|\\]", ""));
			
			//String[] recipients = { "rpappla@deloitte.com" };
			String[] CC = emailCC.split(",");

			InternetAddress[] addressCC = new InternetAddress[CC.length];
			for (int i = 0; i < CC.length; i++) {
				addressCC[i] = new InternetAddress(CC[i]);
			}

			 Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			      protected PasswordAuthentication getPasswordAuthentication() {
			         return new PasswordAuthentication(smtpUsername, smtpPassword);
			      }
			   });

			Message msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress(emailFrom));

			for (String to : recipients) {
				msg.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
			}

			msg.addRecipients(Message.RecipientType.CC, addressCC);
			msg.setSubject(subject + " In " + dev3Urlsheet + " Tag");
			msg.setSentDate(new Date());
			// Create the message part
			BodyPart messageBodyPart = new MimeBodyPart();

			// Now set the actual message
			StringBuffer htmlTxt = new StringBuffer();
			htmlTxt.append("<font face=\"Calibri\" size = '5px'>Hi All,<br/>" + emailTxt1 + "<br/>");
			htmlTxt.append(emailTxt2);
			htmlTxt.append(
					"<br/><br/><b><u>Reminder:</u></b>The thumb rule of the merge process-> Same Developer + Same JIRA ID + Same Comment + Same Set of Files");
			htmlTxt.append(
					"<br/><b><u>For Any Merge Questions</u></b>: Please reach out to Pappla Rajesh - rpappla@deloitte.com or Abhinav Prasoon - aprasoon@deloitte.com . <br/><br/>");
			htmlTxt.append("<br>");
			htmlTxt.append("Regards<br/>CT Dev Team</font></html>");

			messageBodyPart.setContent(htmlTxt.toString(), "text/html");

			// Create a multipart message
			Multipart multipart = new MimeMultipart("related");
			// Set text message part
			multipart.addBodyPart(messageBodyPart);

			// Part two is attachment
			messageBodyPart = new MimeBodyPart();

			DataSource source = new FileDataSource(excelFileName);
			messageBodyPart.setFileName(emailFileName + sdf.format(date) + ".xlsx");
			messageBodyPart.setDataHandler(new DataHandler(source));
			multipart.addBodyPart(messageBodyPart);
			// Send the complete message parts
			msg.setContent(multipart);

			Transport.send(msg);
		} catch (AddressException e) {
			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}

	public int getCalenderMonth(String month) {
		int monthVal = 0;
		switch (month) {
		case "January":
			monthVal = Calendar.JANUARY;
			break;
		case "February":
			monthVal = Calendar.FEBRUARY;
			break;
		case "March":
			monthVal = Calendar.MARCH;
			break;
		case "April":
			monthVal = Calendar.APRIL;
			break;
		case "May":
			monthVal = Calendar.MAY;
			break;
		case "June":
			monthVal = Calendar.JUNE;
			break;
		case "July":
			monthVal = Calendar.JULY;
			break;
		case "August":
			monthVal = Calendar.AUGUST;
			break;
		case "September":
			monthVal = Calendar.SEPTEMBER;
			break;
		case "October":
			monthVal = Calendar.OCTOBER;
			break;
		case "November":
			monthVal = Calendar.NOVEMBER;
			break;
		case "December":
			monthVal = Calendar.DECEMBER;
			break;
		default:
			monthVal = Calendar.OCTOBER;
			break;
		}
		return monthVal;
	}

	public int ordinalIndexOf(String str, String substr, int n) {
		int pos = str.indexOf(substr);
		while (--n > 0 && pos != -1)
			pos = str.indexOf(substr, pos + 1);
		return pos;
	}
	
	public String[] getTags() {
		String[] tagsList = null;
		String tags=Constants.getProperties().getString("avaliabletags");
		tagsList = tags.split(",");
		return tagsList;
	}
	
	 public String readFile(String path, Charset encoding) throws IOException 
	 {
	        byte[] encoded = Files.readAllBytes(Paths.get(path));
	        return encoding.decode(ByteBuffer.wrap(encoded)).toString();
	 }
}
