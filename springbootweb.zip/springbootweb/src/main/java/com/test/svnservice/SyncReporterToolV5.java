package com.test.svnservice;


import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.springframework.util.ResourceUtils;

import com.test.model.ChangeLogEntry;
import com.test.model.ChangePathDetails;
import com.test.model.TagDetails;

public class SyncReporterToolV5 {

	public boolean GenerateReport(TagDetails tObj) {

		boolean isGenerated =true;
		String dev4Url =tObj.getPtagname();
		String dev4Urlhas =tObj.getPtaghas();
		String dev3Url =tObj.getCtagname();
		String dev3Urlhas=tObj.getCtaghas(); 

		try {
			HistoryV5 history = new HistoryV5();
			UtilityCommonV5 util = new UtilityCommonV5();
			String month = Constants.getProperties().getString("Month").toString();
			String date = Constants.getProperties().getString("date").toString();
			String days = "0";

			// JIRA ID TO EXCLUDE FROM REPORT
			List<String> jiraIdListToExclude = new ArrayList<String>();
			List<String> authorListToExclude = new ArrayList<String>();
			
			authorListToExclude.add("venbandi");
			// jiraIdListToExclude.add("CTIE-115537");

			List<ChangeLogEntry> dev04ChangeLog = history.fetchHistory(dev4Url, days, month, date);
			List<ChangeLogEntry> dev03ChangeLog = history.fetchHistory(dev3Url, days, month, date);

			Calendar startDate = Calendar.getInstance();
			int monthVal = util.getCalenderMonth(month);
			int dateVal = Integer.valueOf(date);
			startDate.set(2021, monthVal, dateVal);
			startDate.set(Calendar.HOUR_OF_DAY, 00);
			startDate.set(Calendar.MINUTE, 00);
			startDate.set(Calendar.SECOND, 0);
			startDate.set(Calendar.MILLISECOND, 0);

			List<String> refList04 = new ArrayList<String>();
			for (Iterator<ChangeLogEntry> iterator = dev04ChangeLog.iterator(); iterator.hasNext();) {
				ChangeLogEntry logEntry = iterator.next();
				Timestamp checkInTime = new Timestamp(logEntry.getCheckinDate().getTime());
				Timestamp start = new java.sql.Timestamp(startDate.getTimeInMillis());
				boolean removeentry = true;
				if (jiraIdListToExclude.contains(logEntry.getJiraId())
						|| authorListToExclude.contains(logEntry.getAuthor()) || start.after(checkInTime)) {
					iterator.remove();
					continue;
				}
				List<ChangePathDetails> changePathDetailsList = logEntry.getChangePathDetails();
				for (Iterator<ChangePathDetails> iterator2 = changePathDetailsList.iterator(); iterator2.hasNext();) {

					ChangePathDetails changePathDetails = (ChangePathDetails) iterator2.next();
					/*System.out.println("BEFORE ----> " + logEntry.getAuthor() + "|" + logEntry.getJiraId() + "|"
							+ logEntry.getMessage() + "|" + changePathDetails.getRelativePath());

					System.out.println("AFTER ---->" + logEntry.getAuthor() + "|" + logEntry.getJiraId() + "|"
							+ logEntry.getMessage() + "|"
							+ changePathDetails.getRelativePath().replaceAll(dev4UrlTag, ""));*/

					if (changePathDetails.getRelativePath().toString().contains(dev4Urlhas)) {

						int pos = util.ordinalIndexOf(changePathDetails.getRelativePath(), "/", 3);
						if (pos != -1) {
							removeentry = false;
							refList04.add(logEntry.getAuthor() + "|" + logEntry.getJiraId() + "|"
									+ logEntry.getMessage() + "|" + changePathDetails.getRelativePath().substring(pos));

							System.out.println("ADDED ---->" + logEntry.getAuthor() + "|" + logEntry.getJiraId() + "|"
									+ logEntry.getMessage() + "|" + changePathDetails.getRelativePath().substring(pos));
						} else {
							System.out.println("Matched but backslash not found(/)");
						}

					} else {
						/*System.out.println("REMOVED ---->" + logEntry.getAuthor() + "|" + logEntry.getJiraId() + "|"
								+ logEntry.getMessage() + "|"
								+ changePathDetails.getRelativePath().replaceAll(dev4UrlTag, ""));*/

					}
				}
				if (removeentry) {
					iterator.remove();
				}
			}

			List<String> refList03 = new ArrayList<String>();
			for (Iterator<ChangeLogEntry> iterator = dev03ChangeLog.iterator(); iterator.hasNext();) {
				ChangeLogEntry logEntry = iterator.next();
				Timestamp checkInTime = new Timestamp(logEntry.getCheckinDate().getTime());
				Timestamp start = new java.sql.Timestamp(startDate.getTimeInMillis());
				if (jiraIdListToExclude.contains(logEntry.getJiraId())
						|| authorListToExclude.contains(logEntry.getAuthor()) || start.after(checkInTime)) {
					iterator.remove();
					continue;
				}
				List<ChangePathDetails> changePathDetailsList = logEntry.getChangePathDetails();
				boolean removeentry = true;
				for (Iterator<ChangePathDetails> iterator2 = changePathDetailsList.iterator(); iterator2.hasNext();) {
					ChangePathDetails changePathDetails = (ChangePathDetails) iterator2.next();

					System.out.println("BEFORE ----> " + logEntry.getAuthor() + "|" + logEntry.getJiraId() + "|"
							+ logEntry.getMessage() + "|" + changePathDetails.getRelativePath());

					/*System.out.println("AFTER ---->" + logEntry.getAuthor() + "|" + logEntry.getJiraId() + "|"
							+ logEntry.getMessage() + "|"
							+ changePathDetails.getRelativePath().replaceAll(dev3UrlTag, ""));*/

					if (changePathDetails.getRelativePath().toString().contains(dev3Urlhas)) {

						int pos = util.ordinalIndexOf(changePathDetails.getRelativePath(), "/", 3);
						if (pos != -1) {
							removeentry = false;
							refList03.add(logEntry.getAuthor() + "|" + logEntry.getJiraId() + "|"
									+ logEntry.getMessage() + "|" + changePathDetails.getRelativePath().substring(pos));

							System.out.println("ADDED ---->" + logEntry.getAuthor() + "|" + logEntry.getJiraId() + "|"
									+ logEntry.getMessage() + "|" + changePathDetails.getRelativePath().substring(pos));
						} else {
							System.out.println("Matched but backslash not found(/)");
						}

					} else {
						/*System.out.println("REMOVED ---->" + logEntry.getAuthor() + "|" + logEntry.getJiraId() + "|"
								+ logEntry.getMessage() + "|"
								+ changePathDetails.getRelativePath().replaceAll(dev3UrlTag, ""));*/

					}

				}
				if (removeentry) {
					iterator.remove();
				}
			}

			Set<String> refSet04 = new HashSet<String>(refList04);
			Set<String> refSet03 = new HashSet<String>(refList03);

			// Fetch all change-log present in DEV03 but not in DEV04
			List<ChangeLogEntry> missingFilesInDev04From03Log = new ArrayList<ChangeLogEntry>();
			for (Iterator<ChangeLogEntry> iterator = dev03ChangeLog.iterator(); iterator.hasNext();) {
				ChangeLogEntry missingChangeLogEntry = new ChangeLogEntry();
				ChangeLogEntry changeLogEntry = (ChangeLogEntry) iterator.next();
				missingChangeLogEntry.setAuthor(changeLogEntry.getAuthor());
				missingChangeLogEntry.setCheckinDate(changeLogEntry.getCheckinDate());
				missingChangeLogEntry.setRevisionNumber(changeLogEntry.getRevisionNumber());
				missingChangeLogEntry.setJiraId(changeLogEntry.getJiraId());
				missingChangeLogEntry.setRtcId(changeLogEntry.getMessage());
				List<ChangePathDetails> missingChangePathDetailsList = new ArrayList<ChangePathDetails>();
				List<ChangePathDetails> changePathDetailsList = changeLogEntry.getChangePathDetails();
				for (Iterator<ChangePathDetails> iterator2 = changePathDetailsList.iterator(); iterator2.hasNext();) {
					ChangePathDetails changePathDetails = (ChangePathDetails) iterator2.next();

					String dev03CheckPoint = changeLogEntry.getAuthor() + "|" + changeLogEntry.getJiraId() + "|"
							+ changeLogEntry.getMessage() + "|"
							+ changePathDetails.getRelativePath();
					if (changePathDetails.getRelativePath().toString().contains(dev3Urlhas)) {

						int pos = util.ordinalIndexOf(changePathDetails.getRelativePath(), "/", 3);
						if (pos != -1) {
							dev03CheckPoint = changeLogEntry.getAuthor() + "|" + changeLogEntry.getJiraId() + "|"
									+ changeLogEntry.getMessage() + "|"
									+ changePathDetails.getRelativePath().substring(pos);
						} else {
							System.out.println("Matched but backslash not found(/)");
						}

					}

					if (!refSet04.contains(dev03CheckPoint)) {
						if (!changePathDetails.getRelativePath().contains(dev4Urlhas)) {
							missingChangePathDetailsList.add(changePathDetails);
						}
					}
				}
				missingChangeLogEntry.setChangePathDetails(missingChangePathDetailsList);
				if (missingChangePathDetailsList.size() > 0) {
					missingFilesInDev04From03Log.add(missingChangeLogEntry);
				}
			}

			// Fetch all change-log present in DEV04 but not in DEV05
			List<ChangeLogEntry> missingFilesInDev03From04Log = new ArrayList<ChangeLogEntry>();
			for (Iterator<ChangeLogEntry> iterator = dev04ChangeLog.iterator(); iterator.hasNext();) {
				ChangeLogEntry missingChangeLogEntry = new ChangeLogEntry();
				ChangeLogEntry changeLogEntry = (ChangeLogEntry) iterator.next();
				missingChangeLogEntry.setAuthor(changeLogEntry.getAuthor());
				missingChangeLogEntry.setCheckinDate(changeLogEntry.getCheckinDate());
				missingChangeLogEntry.setRevisionNumber(changeLogEntry.getRevisionNumber());
				missingChangeLogEntry.setJiraId(changeLogEntry.getJiraId());
				missingChangeLogEntry.setRtcId(changeLogEntry.getMessage());
				List<ChangePathDetails> missingChangePathDetailsList = new ArrayList<ChangePathDetails>();
				List<ChangePathDetails> changePathDetailsList = changeLogEntry.getChangePathDetails();
				for (Iterator<ChangePathDetails> iterator2 = changePathDetailsList.iterator(); iterator2.hasNext();) {
					ChangePathDetails changePathDetails = (ChangePathDetails) iterator2.next();
					String dev04CheckPoint = changeLogEntry.getAuthor() + "|" + changeLogEntry.getJiraId() + "|"
							+ changeLogEntry.getMessage() + "|"
							+ changePathDetails.getRelativePath();

					if (changePathDetails.getRelativePath().toString().contains(dev4Urlhas)) {

						int pos = util.ordinalIndexOf(changePathDetails.getRelativePath(), "/", 3);
						if (pos != -1) {
							dev04CheckPoint = changeLogEntry.getAuthor() + "|" + changeLogEntry.getJiraId() + "|"
									+ changeLogEntry.getMessage() + "|"
									+ changePathDetails.getRelativePath().substring(pos);
						} else {
							System.out.println("Matched but backslash not found(/)");
						}

					}
					if (!refSet03.contains(dev04CheckPoint)) {
						if (!changePathDetails.getRelativePath().contains(dev3Urlhas)) {
							missingChangePathDetailsList.add(changePathDetails);
						}
					}
				}
				missingChangeLogEntry.setChangePathDetails(missingChangePathDetailsList);
				if (missingChangePathDetailsList.size() > 0) {
					missingFilesInDev03From04Log.add(missingChangeLogEntry);
				}
			}

			if("SEM".equalsIgnoreCase(tObj.getRoption()))
			{
				List<String> userIds = new ArrayList<String>();
				userIds.add(tObj.getEmail());
				util.writeXLSXFile(dev04ChangeLog, dev03ChangeLog, missingFilesInDev03From04Log, tObj);
				String emailCC ="rpappla@DELOITTE.com,aprasoon@DELOITTE.com";
				util.sendWithAttachment(tObj.getCfilename(), tObj.getPfilename(), userIds,emailCC);
			}
			else if("SED".equalsIgnoreCase(tObj.getRoption()))
			{
				if(missingFilesInDev03From04Log.size() >0)
				{
					List<String> userIds =util.writeXLSXFile(dev04ChangeLog, dev03ChangeLog, missingFilesInDev03From04Log, tObj);
					userIds.add(tObj.getEmail());
					String emailCC ="rpappla@DELOITTE.com,aprasoon@DELOITTE.com,pranshetty@deloitte.com,pshanmukham@DELOITTE.com,lmantri@deloitte.com,mnarendraharsha@deloitte.com,vimraina@deloitte.com,gajindal@deloitte.com";
					util.sendWithAttachment(tObj.getCfilename(), tObj.getPfilename(), userIds,emailCC);
				}
			}
			/*else if("DMR".equalsIgnoreCase(tObj.getRoption()))
			{
				util.writeXLSXFile(dev04ChangeLog, dev03ChangeLog, missingFilesInDev03From04Log, tObj);
			}*/
			else
			{
				isGenerated = false;
			}
			//util.sendWithAttachment(dev3Urlsheet, dev4Urlsheet, userIds);
		} catch (Exception e) {
			isGenerated = false;
			e.printStackTrace();
		} 
		return isGenerated;
	}

}
