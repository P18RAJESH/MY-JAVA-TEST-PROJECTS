package com.test.svnservice;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNLogEntry;
import org.tmatesoft.svn.core.SVNLogEntryPath;
import org.tmatesoft.svn.core.SVNURL;
import org.tmatesoft.svn.core.auth.ISVNAuthenticationManager;
import org.tmatesoft.svn.core.internal.io.dav.DAVRepositoryFactory;
import org.tmatesoft.svn.core.internal.io.fs.FSRepositoryFactory;
import org.tmatesoft.svn.core.internal.io.svn.SVNRepositoryFactoryImpl;
import org.tmatesoft.svn.core.internal.wc2.ng.SvnDiffGenerator;
import org.tmatesoft.svn.core.io.SVNRepository;
import org.tmatesoft.svn.core.wc.SVNRevision;
import org.tmatesoft.svn.core.wc.SVNWCUtil;
import org.tmatesoft.svn.core.wc2.ISvnObjectReceiver;
import org.tmatesoft.svn.core.wc2.SvnDiff;
import org.tmatesoft.svn.core.wc2.SvnLog;
import org.tmatesoft.svn.core.wc2.SvnOperationFactory;
import org.tmatesoft.svn.core.wc2.SvnRevisionRange;
import org.tmatesoft.svn.core.wc2.SvnTarget;
import com.test.model.ChangeLogEntry;
import com.test.model.ChangePathDetails;

/*
 * The following example program demonstrates how you can use SVNRepository to
 * obtain a history for a range of revisions including (for each revision): all
 * changed paths, log message, the author of the commit, the timestamp when the 
 * commit was made. It is similar to the "svn log" command supported by the 
 * Subversion client library.
 * 
 * 
 */
public class HistoryV5 {

	private List<ChangeLogEntry> changeLogEntryList;

	public List<ChangeLogEntry> fetchHistory(String branchPath, String days, String month, String date)
			throws SVNException, UnsupportedEncodingException, ParseException {

		UtilityCommonV5 util = new UtilityCommonV5();
		changeLogEntryList = new ArrayList<ChangeLogEntry>();

		setupLibrary();

		final SvnOperationFactory svnOperationFactory = new SvnOperationFactory();
		try {
			ISVNAuthenticationManager authManager = SVNWCUtil.createDefaultAuthenticationManager(Constants.getProperties().getString("SVN_USERNAME"), Constants.getProperties().getString("SVN_PASSWORD"));
			svnOperationFactory.setAuthenticationManager(authManager);
			final SvnLog log = svnOperationFactory.createLog();
			Calendar monthBack = Calendar.getInstance();
			int subDays = Integer.valueOf(days);
	
			// get the time zone
			monthBack.set(Calendar.DATE, -subDays);
			monthBack.set(Calendar.HOUR_OF_DAY, 00);
			monthBack.set(Calendar.MINUTE, 00);
			monthBack.set(Calendar.SECOND, 0);
			monthBack.set(Calendar.MILLISECOND, 0);
			// get the time zone
			Calendar dev3Start = Calendar.getInstance();
			int monthVal = util.getCalenderMonth(month);
			int dateVal = Integer.valueOf(date);
			dev3Start.set(2019, monthVal, dateVal);
			dev3Start.set(Calendar.HOUR_OF_DAY, 00);
			dev3Start.set(Calendar.MINUTE, 00);
			dev3Start.set(Calendar.SECOND, 0);
			dev3Start.set(Calendar.MILLISECOND, 0);

			TimeZone tz = monthBack.getTimeZone();

			// print the time zone name for this calendar
			System.out.println("Calendar is :" + monthBack.getTime());
			System.out.println("The time zone is :" + tz.getDisplayName());

			Calendar calNow = Calendar.getInstance();

			Date date1 = monthBack.getTime();
			Date date2 = dev3Start.getTime();

			if (date1.compareTo(date2) > 0) {
				System.out.println("Date1 is after Date2");
				log.addRange(SvnRevisionRange.create(SVNRevision.create(monthBack.getTime()),
						SVNRevision.create(calNow.getTime())));
			} else if (date1.compareTo(date2) < 0) {
				System.out.println("Date1 is before Date2");
				log.addRange(SvnRevisionRange.create(SVNRevision.create(dev3Start.getTime()),
						SVNRevision.create(calNow.getTime())));
			} else {
				System.out.println("Date1 is equal to Date2");
				log.addRange(SvnRevisionRange.create(SVNRevision.create(monthBack.getTime()),
						SVNRevision.create(calNow.getTime())));
			}

			log.setDiscoverChangedPaths(true);
			log.setSingleTarget(SvnTarget.fromURL(SVNURL.parseURIEncoded(branchPath)));
			log.setReceiver(new ISvnObjectReceiver<SVNLogEntry>() {
				@Override
				public void receive(SvnTarget target, SVNLogEntry logEntry) throws SVNException {
					System.out.println(logEntry);

					ChangeLogEntry changeLogEntry = new ChangeLogEntry();
					changeLogEntry.setAuthor(logEntry.getAuthor());
					changeLogEntry.setCheckinDate(logEntry.getDate());
					changeLogEntry.setMessage(logEntry.getMessage());
					String jiraIDValue = logEntry.getMessage().toString().trim().split("\\s+")[0].trim();
					changeLogEntry.setJiraId(jiraIDValue);
					Map<String, String> jiraDetails = new HashMap<String, String>();
					changeLogEntry.setRtcId(jiraDetails.get("RTCID"));
					changeLogEntry.setAssigneeName(jiraDetails.get("ASSIGNEE"));
					changeLogEntry.setIssueStatus(jiraDetails.get("issuestatus"));
					changeLogEntry.setUpdateDate(jiraDetails.get("updateDate"));
					changeLogEntry.setRevisionNumber(logEntry.getRevision());
					List<ChangePathDetails> changePathDetailsList = new ArrayList<ChangePathDetails>();
					ChangePathDetails changePathDetails;
					if (logEntry.getChangedPaths().size() > 0) {
						Set changedPathsSet = logEntry.getChangedPaths().keySet();
						for (Iterator changedPaths = changedPathsSet.iterator(); changedPaths.hasNext();) {
							SVNLogEntryPath entryPath = (SVNLogEntryPath) logEntry.getChangedPaths()
									.get(changedPaths.next());
							if (!entryPath.getPath().contains("AutomatedUnitTestFramework")
									&& !entryPath.getPath().contains("UtilityTools_comp")
									&& !entryPath.getPath().contains("CaseCopy_CaseClone_comp")
									&& !entryPath.getPath().contains("Informatica_comp")) {
								// ByteArrayOutputStream byteArrayOutputStream =
								// new ByteArrayOutputStream();
								changePathDetails = new ChangePathDetails();
								changePathDetails.setAction((entryPath.getType() == 'M') ? "Modified"
										: ((entryPath.getType() == 'A') ? "Added"
												: ((entryPath.getType() == 'R') ? "Replaced" : "Deleted")));
								changePathDetails.setRelativePath(entryPath.getPath());
								changePathDetails.setCopyPath(
										((entryPath.getCopyPath() != null) ? " (from " + entryPath.getCopyPath()
												+ " revision " + entryPath.getCopyRevision() + ")" : ""));
								changePathDetailsList.add(changePathDetails);
							}

						}
					}
					changeLogEntry.setChangePathDetails(changePathDetailsList);
					if (!changeLogEntry.getJiraId().replaceAll("[^0-9]", "").equals("1306")
							|| changePathDetailsList.isEmpty()) {
						changeLogEntryList.add(changeLogEntry);
					}
				}
			});
			log.run();
		} finally {
			svnOperationFactory.dispose();
		}
		return changeLogEntryList;

	}

	/*
	 * Initializes the library to work with a repository via different
	 * protocols.
	 */
	private static void setupLibrary() {
		/*
		 * For using over http:// and https://
		 */
		DAVRepositoryFactory.setup();
		/*
		 * For using over svn:// and svn+xxx://
		 */
		SVNRepositoryFactoryImpl.setup();

		/*
		 * For using over file:///
		 */
		FSRepositoryFactory.setup();
	}

}