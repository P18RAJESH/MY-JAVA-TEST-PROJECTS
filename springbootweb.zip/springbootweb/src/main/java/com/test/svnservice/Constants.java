package com.test.svnservice;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ResourceBundle;

public class Constants {
	private static ResourceBundle rb = null;
	static{
		try {
			rb = ResourceBundle.getBundle("application");
			makeOutputDirectory();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static ResourceBundle getProperties(){
		return rb;
	}
	
	public static String getOutputFolder() {
		return System.getProperty("user.home")+"\\SVNMerge\\OutputFiles\\";
	}
	public static void makeOutputDirectory() {
		File file = new File(Constants.getOutputFolder());
		boolean dirCreated = file.mkdir();
		if(dirCreated) {
		      System.out.println("The "+ getOutputFolder() +" directory is created.");
		    }
		    else {
		      System.out.println("The "+ getOutputFolder() +" already exists.");
		    }
	}
}
