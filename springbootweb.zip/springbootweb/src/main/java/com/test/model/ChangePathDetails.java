package com.test.model;

public class ChangePathDetails {

	private String action;
	private String relativePath;
	private String copyPath;
	/**
	 * @return the copyPath
	 */
	public String getCopyPath() {
		return copyPath;
	}
	/**
	 * @param copyPath the copyPath to set
	 */
	public void setCopyPath(String copyPath) {
		this.copyPath = copyPath;
	}
	private String difference;
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
	/**
	 * @return the relativePath
	 */
	public String getRelativePath() {
		return relativePath;
	}
	/**
	 * @param relativePath the relativePath to set
	 */
	public void setRelativePath(String relativePath) {
		this.relativePath = relativePath;
	}
	/**
	 * @return the difference
	 */
	public String getDifference() {
		return difference;
	}
	/**
	 * @param difference the difference to set
	 */
	public void setDifference(String difference) {
		this.difference = difference;
	}
	
}
