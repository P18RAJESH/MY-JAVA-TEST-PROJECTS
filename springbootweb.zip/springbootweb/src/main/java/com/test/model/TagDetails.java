package com.test.model;

import com.test.svnservice.UtilityCommonV5;

public class TagDetails {

	private String ptagname;
	private String ctagname;
	private String email;
	private String roption;
	private String ptaghas;
	private String ctaghas;
	private String pfilename;
	private String cfilename;
	
	public TagDetails(String ptagname,String ctagname,String email,String roption) {
		super();
		UtilityCommonV5 util = new UtilityCommonV5();
		this.ptagname = "https://AE1BWDSSSVN01.ctdssaws.local/svn/CTIE/UAT-Tags/"+ptagname;
		this.ctagname = "https://AE1BWDSSSVN01.ctdssaws.local/svn/CTIE/UAT-Tags/"+ctagname;
		this.ptaghas=this.ptagname.substring(util.ordinalIndexOf(this.ptagname, "/", 5)).substring(0,util.ordinalIndexOf(this.ptagname.substring(util.ordinalIndexOf(this.ptagname, "/", 5)), ".", 2));
		this.ctaghas=this.ctagname.substring(util.ordinalIndexOf(this.ctagname, "/", 5)).substring(0,util.ordinalIndexOf(this.ctagname.substring(util.ordinalIndexOf(this.ctagname, "/", 5)), ".", 2));
		this.pfilename=this.ptaghas.substring(util.ordinalIndexOf(this.ptaghas, "-", 2)+1);
		this.cfilename=this.ctaghas.substring(util.ordinalIndexOf(this.ctaghas, "-", 2)+1);
		this.email = email;
		this.roption = roption;
	}
	
	public TagDetails(TagDetails Obj) {
		super();
		UtilityCommonV5 util = new UtilityCommonV5();
		this.ptagname = "https://AE1BWDSSSVN01.ctdssaws.local/svn/CTIE/UAT-Tags/"+Obj.getPtagname();
		this.ctagname = "https://AE1BWDSSSVN01.ctdssaws.local/svn/CTIE/UAT-Tags/"+Obj.getCtagname();
		this.ptaghas=this.ptagname.substring(util.ordinalIndexOf(this.ptagname, "/", 5)).substring(0,util.ordinalIndexOf(this.ptagname.substring(util.ordinalIndexOf(this.ptagname, "/", 5)), ".", 2));
		this.ctaghas=this.ctagname.substring(util.ordinalIndexOf(this.ctagname, "/", 5)).substring(0,util.ordinalIndexOf(this.ctagname.substring(util.ordinalIndexOf(this.ctagname, "/", 5)), ".", 2));
		this.pfilename=this.ptaghas.substring(util.ordinalIndexOf(this.ptaghas, "-", 2)+1);
		this.cfilename=this.ctaghas.substring(util.ordinalIndexOf(this.ctaghas, "-", 2)+1);
		this.email = Obj.getEmail();
		this.roption = Obj.getRoption();
	}
	
	public TagDetails() {
		super();
	}

	@Override
	public String toString() {
		return "TagDetails [ptagname=" + ptagname + ", ctagname=" + ctagname + ", email=" + email + ", roption="
				+ roption + ", ptaghas=" + ptaghas + ", ctaghas=" + ctaghas + ", pfilename=" + pfilename
				+ ", cfilename=" + cfilename + "]";
	}
	public String getPtagname() {
		return ptagname;
	}
	public void setPtagname(String ptagname) {
		this.ptagname = ptagname;
	}
	public String getCtagname() {
		return ctagname;
	}
	public void setCtagname(String ctagname) {
		this.ctagname = ctagname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRoption() {
		return roption;
	}
	public void setRoption(String roption) {
		this.roption = roption;
	}
	public String getPtaghas() {
		return ptaghas;
	}
	public void setPtaghas(String ptaghas) {
		this.ptaghas = ptaghas;
	}
	public String getCtaghas() {
		return ctaghas;
	}
	public void setCtaghas(String ctaghas) {
		this.ctaghas = ctaghas;
	}
	public String getPfilename() {
		return pfilename;
	}
	public void setPfilename(String pfilename) {
		this.pfilename = pfilename;
	}
	public String getCfilename() {
		return cfilename;
	}
	public void setCfilename(String cfilename) {
		this.cfilename = cfilename;
	}
	
}
