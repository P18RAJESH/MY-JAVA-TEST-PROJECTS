package com.test.model;

import java.util.Date;
import java.util.List;

public class ChangeLogEntry {

	private long revisionNumber;
	private String author;
	private Date checkinDate;
	private String message;
	private String jiraId;
	private String rtcId;
	private String assigneeName;
	private String issueStatus;
	private String updateDate;
	private String defectType;
	private String testPhase;
	private String defectApproved;
	private String defectApprovedBy;
	private String jiraStatusUpdateDt;
	private String team;
	private String severity;
	
	public String getTeam()
	{
		return team;
	}
	public void setTeam(String team)
	{
		this.team = team;
	}
	
	public String getSeverity()
	{
		return severity;
	}
	public void setSeverity(String severity)
	{
		this.severity = severity;
	}
	public String getDefectApprovedBy()
	{
		return defectApprovedBy;
	}
	public void setDefectApprovedBy(String defectApprovedBy)
	{
		this.defectApprovedBy = defectApprovedBy;
	}

	public String getJiraStatusUpdateDt()
	{
		return jiraStatusUpdateDt;
	}
	public void setJiraStatusUpdateDt(String jiraStatusUpdateDt)
	{
		this.jiraStatusUpdateDt = jiraStatusUpdateDt;
	}
	public String getDefectType()
	{
		return defectType;
	}
	public void setDefectType(String defectType)
	{
		this.defectType = defectType;
	}
	public String getTestPhase()
	{
		return testPhase;
	}
	public void setTestPhase(String testPhase)
	{
		this.testPhase = testPhase;
	}
	public String getDefectApproved()
	{
		return defectApproved;
	}
	public void setDefectApproved(String defectApproved)
	{
		this.defectApproved = defectApproved;
	}
	public String getIssueStatus() {
		return issueStatus;
	}
	public String getUpdateDate()
	{
		return updateDate;
	}
	public void setUpdateDate(String updateDate)
	{
		this.updateDate = updateDate;
	}
	public void setIssueStatus(String issueStatus) {
		this.issueStatus = issueStatus;
	}
	/**
	 * @return the rtcId
	 */
	public String getRtcId() {
		return rtcId;
	}
	/**
	 * @param rtcId the rtcId to set
	 */
	public void setRtcId(String rtcId) {
		this.rtcId = rtcId;
	}
	private List<ChangePathDetails> changePathDetails;
	
	/**
	 * @return the revisionNumber
	 */
	public long getRevisionNumber() {
		return revisionNumber;
	}
	/**
	 * @return the jiraId
	 */
	public String getJiraId() {
		return jiraId;
	}
	/**
	 * @param jiraId the jiraId to set
	 */
	public void setJiraId(String jiraId) {
		String jiraIds[]= jiraId.split("(?<=\\d)(?=\\D)");
		this.jiraId = jiraIds[0];
	}
	/**
	 * @param revisionNumber the revisionNumber to set
	 */
	public void setRevisionNumber(long revisionNumber) {
		this.revisionNumber = revisionNumber;
	}
	/**
	 * @return the author
	 */
	public String getAuthor() {
		return author;
	}
	/**
	 * @param author the author to set
	 */
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getAssigneeName() {
		return assigneeName;
	}
	public void setAssigneeName(String assigneeName) {
		this.assigneeName = assigneeName;
	}
	/**
	 * @return the checkinDate
	 */
	public Date getCheckinDate() {
		return checkinDate;
	}
	/**
	 * @param checkinDate the checkinDate to set
	 */
	public void setCheckinDate(Date checkinDate) {
		this.checkinDate = checkinDate;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * @return the changePathDetails
	 */
	public List<ChangePathDetails> getChangePathDetails() {
		return changePathDetails;
	}
	/**
	 * @param changePathDetails the changePathDetails to set
	 */
	public void setChangePathDetails(List<ChangePathDetails> changePathDetails) {
		this.changePathDetails = changePathDetails;
	}
	
}
