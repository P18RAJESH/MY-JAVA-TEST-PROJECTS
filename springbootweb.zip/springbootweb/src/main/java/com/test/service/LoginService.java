package com.test.service;

import org.springframework.stereotype.Service;

@Service
public class LoginService {
	public boolean generateReport(String ptagname, String ctagname) {
		return true;
	}
}
