package com.springboot.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class JournalEntry {
	
	@Id
	private String Lname;
	private String Lurl;
	private String Ldesc;
	public String getLname() {
		return Lname;
	}
	public void setLname(String lname) {
		Lname = lname;
	}
	public String getLurl() {
		return Lurl;
	}
	public void setLurl(String lurl) {
		Lurl = lurl;
	}
	public String getLdesc() {
		return Ldesc;
	}
	public void setLdesc(String ldesc) {
		Ldesc = ldesc;
	}
	@Override
	public String toString() {
		return "JournalEntry [Lname=" + Lname + ", Lurl=" + Lurl + ", Ldesc=" + Ldesc + "]";
	}
	
	

	
}
