package com.springboot.demo.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.springboot.demo.dao.JournalEntryRepository;
import com.springboot.demo.model.JournalEntry;

@Controller
public class JournalEntryController {
	
	@Autowired
	JournalEntryRepository repo;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView index() {
		
		ModelAndView mv= new ModelAndView();
		List<JournalEntry> entries= repo.findAll();
		mv.addObject("entries",entries);
		mv.setViewName("index.jsp");
		return mv;
	}
	
	//Create and Update
	@RequestMapping(value = "/", method = RequestMethod.POST)		
	public ModelAndView addJournalEntry(JournalEntry entry) {
		System.out.println(entry);
		repo.save(entry);
		return new ModelAndView("redirect:/");
	}
	
	@RequestMapping(value = "/deleteEntry")		
	public ModelAndView  deleteJournalEntry(@RequestParam String deleteID) {
		System.out.println(deleteID);
		repo.deleteById(deleteID);
		return new ModelAndView("redirect:/");
	}
}
