package com.codescanner.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.codescanner.Impl.SearchWordImplementation;
import com.codescanner.constants.Constants;
import com.codescanner.utility.CodeScannerUtility;


@Controller
public class CodeScannerController {
	@RequestMapping(value = "/CodeScanner", method = RequestMethod.GET)
	public String init(Model model) {
		return "searchUtility.jsp";
	}

	
	@RequestMapping(value = "searchWord", method = RequestMethod.POST)
	public String searchWord(@RequestParam(required = false, name = "word") String wordToSearch,
			@RequestParam(required = false, name = "readExcel") MultipartFile excelFile,
			@RequestParam(required = false, name = "wholeWord") String wholeWord,
			@RequestParam(required = false, name = "caseSens") String caseSensitive,
			@RequestParam(required = false, name = "previousLine") String previousLine, 
			@RequestParam(required = false, name = "envs") String envs,
			@RequestParam(required = false, name = "displayCode") String displayCd, Model model) throws Exception {
		ArrayList<String> wordsToSearchList = new ArrayList<String>();
		String env = null;
		if (null != wordToSearch && !wordToSearch.equals("")) {
			wordsToSearchList.add(wordToSearch);
		} else {
			wordsToSearchList = new SearchWordImplementation().readExcel(excelFile);
		}
		if(null == envs || envs.isEmpty()) {
			return "error.jsp";
		}
		if (!wordsToSearchList.isEmpty()) {
			env = Constants.getEnvProperty(envs);
			new SearchWordImplementation().searchWord(env,
					wordsToSearchList, wholeWord, caseSensitive, previousLine,displayCd);
			System.out.println("please find search results of word : " + wordsToSearchList.get(0));
			if(wordsToSearchList.size() > 1) {
				model.addAttribute("filePath", Constants.getOutputFolder()+ "\\ListOfWords.xlsx");
			}else {
				model.addAttribute("filePath", Constants.getOutputFolder()+ "\\"
						+ CodeScannerUtility.escapeSpecialCharactersInOpFile(wordsToSearchList.get(0)) + ".xlsx");	
			}		
			return "fileExists.jsp";
		} else {
			return "searchUtility.jsp";
		}
	}


	@RequestMapping(method = RequestMethod.GET)
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (null != request && null != request.getParameter("getparam")) {
			String anchorValue1 = request.getParameter("getparam");
			System.out.println("anchorValue1:::" + anchorValue1);
			PrintWriter out = response.getWriter();
			response.setContentType("APPLICATION/OCTET-STREAM");
			response.setHeader("Content-Disposition",
					"attachment; filename=\"" + anchorValue1.substring(anchorValue1.lastIndexOf("/") + 1) + "\"");
			FileInputStream fileInputStream = new FileInputStream(anchorValue1);
			int i;
			while ((i = fileInputStream.read()) != -1) {
				out.write(i);
			}
			fileInputStream.close();
		}
	}

}
