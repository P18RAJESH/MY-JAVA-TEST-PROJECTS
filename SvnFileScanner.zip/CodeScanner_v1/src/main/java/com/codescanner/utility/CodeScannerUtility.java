package com.codescanner.utility;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.text.CharacterIterator;
import java.text.StringCharacterIterator;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class CodeScannerUtility {
	Connection con = null;
	public static HSSFSheet writeToSheet(HSSFSheet sheet,ArrayList<String> columnsList,String rowType,int count){
		HSSFRow rowhead = sheet.createRow((int) count);
		 /* Font font = sheet.getWorkbook().createFont();
	      font.setFontHeightInPoints((short) 10);
	      font.setFontName("Segoe UI");      
	      style.setFont(font);*/
		for(int i=0 ; i<columnsList.size();i++){
			
			Cell cell = rowhead.createCell((int) i);
			cell.setCellValue(columnsList.get(i));
			if (rowType.equals("HEADER")) {
				/*font.setFontHeightInPoints((short) 12);
				font.setBoldweight((short) 1000);	
				style.setFont(font);*/
			}
				//cell.setCellStyle(style);
			
		}	
		return sheet;
		}	
	
	 public static List<String> listfilesInDirectory(String directoryName) {
		 List<String> collect = new ArrayList<String>();	        
		 Path start = Paths.get(directoryName);
			try (Stream<Path> stream = Files.walk(start, Integer.MAX_VALUE)) {
			    collect = stream.filter(s -> s.toString().endsWith(".java") || s.toString().endsWith(".jsp") || s.toString().endsWith(".xml") 
			    		|| s.toString().endsWith(".html") || s.toString().endsWith(".txt") || s.toString().endsWith(".properties") || s.toString().endsWith(".wsdl")
			    		|| s.toString().endsWith(".xsd") || s.toString().endsWith(".xmi") || s.toString().endsWith(".bat") || s.toString().endsWith(".ksh")
			    		|| s.toString().endsWith(".js") || s.toString().endsWith(".css") || s.toString().endsWith(".tld") || s.toString().endsWith(".xsl")
			    		|| s.toString().endsWith(".htm") || s.toString().endsWith(".cs"))
			        .map(String::valueOf)
			        .sorted()
			        .collect(Collectors.toList());
			    
			    collect.forEach(System.out::println);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			 return collect;
	    } 
	 
	 public static boolean isDirectoryEmpty(Path path) throws IOException {
		    if (Files.isDirectory(path)) {
		        try (Stream<Path> entries = Files.list(path)) {
		            return !entries.findFirst().isPresent();
		        }
		    }
		        
		    return false;
		}
	 public static String escapeSpecialCharacters(String aRegexFragment){
		    final StringBuilder result = new StringBuilder();

		    final StringCharacterIterator iterator = 
		      new StringCharacterIterator(aRegexFragment)
		    ;
		    char character =  iterator.current();
		    while (character != CharacterIterator.DONE ){
		      /*
		       All literals need to have backslashes doubled.
		      */
		      if (character == '.') {
		        result.append("\\.");
		      }
		      else if (character == '\\') {
		        result.append("\\\\");
		      }
		      else if (character == '?') {
		        result.append("\\?");
		      }
		      else if (character == '*') {
		        result.append("\\*");
		      }
		      else if (character == '+') {
		        result.append("\\+");
		      }
		      else if (character == '&') {
		        result.append("\\&");
		      }
		      else if (character == ':') {
		        result.append("\\:");
		      }
		      else if (character == '{') {
		        result.append("\\{");
		      }
		      else if (character == '}') {
		        result.append("\\}");
		      }
		      else if (character == '[') {
		        result.append("\\[");
		      }
		      else if (character == ']') {
		        result.append("\\]");
		      }
		      else if (character == '(') {
		        result.append("\\(");
		      }
		      else if (character == ')') {
		        result.append("\\)");
		      }
		      else if (character == '^') {
		        result.append("\\^");
		      }
		      else if (character == '$') {
		        result.append("\\$");
		      }
		      else {
		        //the char is not a special one
		        //add it to the result as is
		        result.append(character);
		      }
		      character = iterator.next();
		    }
		    return result.toString();
		  }
	 public static void writeRowData(List<String> cellValues, String flag, XSSFWorkbook workbook, String sheetName){
			XSSFSheet sheet = workbook.getSheet(sheetName);
			if(sheet.getSheetName().toUpperCase().contains("VERSION")){
				sheet.autoSizeColumn(0);
				sheet.protectSheet("whoru");
			}
			int rowIndex = sheet.getLastRowNum();
			XSSFRow row = null;
			XSSFCell cell = null;
			int cellsCount = cellValues.size();
			CellStyle headingStyle = workbook.createCellStyle();
			headingStyle.setFillForegroundColor(IndexedColors.GREEN.getIndex());
			headingStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);		
			headingStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			headingStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			headingStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
			Font font = workbook.createFont();
			font.setColor(IndexedColors.WHITE.getIndex());
			font.setBoldweight(Font.BOLDWEIGHT_BOLD);
			font.setFontName("Segoe UI");
			font.setFontHeightInPoints((short) 10);
			headingStyle.setFont(font);
			
			CellStyle normalStyle = workbook.createCellStyle();
			normalStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			normalStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			normalStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
			Font normalfont = workbook.createFont();
			normalfont.setFontName("Segoe UI");		
			normalfont.setFontHeightInPoints((short) 10);
			normalStyle.setFont(normalfont);
	
			if("heading".equalsIgnoreCase(flag)){			 		 
				rowIndex = sheet.getLastRowNum();
				if(rowIndex!= 0){
					rowIndex = rowIndex+2;			
				}
				row = sheet.createRow(rowIndex);
				for(int i=0;i<cellsCount;i++){
					cell = row.createCell(i);
					cell.setCellStyle(headingStyle);
					cell.setCellValue(cellValues.get(i));
					sheet.autoSizeColumn(i);
				}
				sheet.createFreezePane(0, 1);
			}else if("rows".equalsIgnoreCase(flag)){
				rowIndex = rowIndex+1;
				row = sheet.createRow(rowIndex);				
				for(int i=0;i<cellsCount;i++){
					cell = row.createCell(i);	
					String cellValue = cellValues.get(i);
					cell.setCellStyle(normalStyle);
					cell.setCellValue(cellValue);			
					sheet.autoSizeColumn(i);
				}
			}		
		}		
	 public static String createWorkSheet(String sheetName,XSSFWorkbook workbook) throws FileNotFoundException, IOException{		
		    int rowIndex =0;
		    Row headerRow = workbook.createSheet(sheetName).createRow(rowIndex++);
		    CellStyle style = workbook.createCellStyle();
		    style.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
		    style.setFillPattern(CellStyle.SOLID_FOREGROUND); 
		    
		    Cell cell0 = headerRow.createCell(0);
		    		cell0.setCellStyle(style);
		    	
		    Cell cell1 = headerRow.createCell(1);
		    cell1.setCellStyle(style);

		    
		    return sheetName;
		}
	 public static String escapeSpecialCharactersInOpFile(String aRegexFragment){
		    final StringBuilder result = new StringBuilder();
		    boolean isSpl = false;
		    final StringCharacterIterator iterator = 
		      new StringCharacterIterator(aRegexFragment)
		    ;
		    char character =  iterator.current();
		    while (character != CharacterIterator.DONE ){
		      /*
		       All literals need to have backslashes doubled.
		      */
		      if (character == '.') {
		    	  isSpl =  true;
		    	  break;
		      }
		      else if (character == '\\') {
		    	  isSpl =  true;
		    	  break;
		      }
		      else if (character == '?') {
		    	  isSpl =  true;
		    	  break;
		      }
		      else if (character == '*') {
		    	  isSpl =  true;
		    	  break;
		      }
		      else if (character == '+') {
		    	  isSpl =  true;
		    	  break;
		      }
		      else if (character == '&') {
		    	  isSpl =  true;
		    	  break;
		      }
		      else if (character == ':') {
		    	  isSpl =  true;
		    	  break;
		      }
		      else if (character == '{') {
		    	  isSpl =  true;
		    	  break;
		      }
		      else if (character == '}') {
		    	  isSpl =  true;
		    	  break;
		      }
		      else if (character == '[') {
		    	  isSpl =  true;
		    	  break;
		      }
		      else if (character == ']') {
		    	  isSpl =  true;
		    	  break;
		      }
		      else if (character == '(') {
		    	  isSpl =  true;
		    	  break;
		      }
		      else if (character == ')') {
		    	  isSpl =  true;
		    	  break;
		      }
		      else if (character == '^') {
		    	  isSpl =  true;
		    	  break;
		      }
		      else if (character == '$') {
		    	  isSpl =  true;
		    	  break;
		      }
		      else if (character == '"') {
		    	  isSpl =  true;
		    	  break;
			      }
		      else if (character == '\'') {
		    	  isSpl =  true;
		    	  break;
			      }
		     
		      character = iterator.next();
		    }
		    if(isSpl) {
		    	return "CodeSnippet";
		    }
		    else {
		    	return aRegexFragment;
		    }
		  } 

}
