package com.codescanner.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

import com.codescanner.constants.Constants;
@Import({com.codescanner.controller.CodeScannerController.class,com.codescanner.controller.CodeScannerErrorController.class})

@SpringBootApplication
public class Application extends Constants{
    public static void main(String[] args) throws Exception {
        SpringApplication.run(Application.class, args);
    }
}
