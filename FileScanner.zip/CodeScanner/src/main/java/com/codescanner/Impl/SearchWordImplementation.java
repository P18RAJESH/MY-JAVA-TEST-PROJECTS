package com.codescanner.Impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.lucene.analysis.SimpleAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import com.codescanner.constants.Constants;
import com.codescanner.utility.CodeScannerUtility;

public class SearchWordImplementation {
	
	static boolean isCaseSensitive = false;
	static boolean isWholeWord  = false;
	static boolean needPreviousLine = false;
	static boolean codeNeeded = false;
	static String projectName = null;
	public void indexFiles(String directoryName, String indexDirectory) throws Exception {
		File dataDir = new File(directoryName);
    	//This will be indexed directory...All the folders and files read in the parent directory will be indexed in to this folder. Due to indexing , WORD search shows significant efficiency in terms of time.
        File indexDir = new File(indexDirectory);
		index(indexDir, dataDir, "");
	}
	private static int index(File indexDir, File dataDir, String suffix) throws Exception {        
        IndexWriter indexWriter = new IndexWriter( FSDirectory.open(indexDir), new SimpleAnalyzer(), true, IndexWriter.MaxFieldLength.LIMITED);
        indexWriter.setUseCompoundFile(false);        
        indexDirectory(indexWriter, dataDir,suffix);        
        int numIndexed = indexWriter.maxDoc();
        indexWriter.optimize();
        indexWriter.close();        
        return numIndexed;        
    }
	private static void indexDirectory(IndexWriter indexWriter, File dataDir,String suffix) throws Exception {
        File[] files = dataDir.listFiles();
        for (int i = 0; i < files.length; i++) {
            File f = files[i];
            if (f.isDirectory()) {
                indexDirectory(indexWriter, f,suffix);
            }
            else {
                indexFileWithIndexWriter(indexWriter, f,suffix);
            }
        }

    }
    
    private static void indexFileWithIndexWriter(IndexWriter indexWriter, File f,String suffix) throws Exception {
        if (f.isHidden() || f.isDirectory() || !f.canRead() || !f.exists()) {
            return;
        }
        
        // If you want all extensions, instead of just �java�, then you can leave out that parameter. This would change the �index�, �indexDirectory�, and �indexFileWithIndexWriter� constructors to not have the parameter passed in. 
        //Finally, you would want to remove:
      String s = f.getName();
        if (!(s.toString().endsWith(".java") || s.toString().endsWith(".jsp") || s.toString().endsWith(".xml") 
	    		|| s.toString().endsWith(".html") || s.toString().endsWith(".txt") || s.toString().endsWith(".properties") || s.toString().endsWith(".wsdl")
	    		|| s.toString().endsWith(".xsd") || s.toString().endsWith(".xmi") || s.toString().endsWith(".bat") || s.toString().endsWith(".ksh")
	    		|| s.toString().endsWith(".js") || s.toString().endsWith(".css") || s.toString().endsWith(".tld") || s.toString().endsWith(".xsl")
	    		|| s.toString().endsWith(".htm") || s.toString().endsWith(".cs"))) {
            return;
        }
        if(!f.getCanonicalPath().contains(".svn")){
        Document doc = new Document();
        doc.add(new Field("contents", new FileReader(f)));        
        doc.add(new Field("filename", f.getCanonicalPath(), Field.Store.YES, Field.Index.ANALYZED));        
        indexWriter.addDocument(doc);
        }
    }
public void searchWord(String indexDirectory, ArrayList<String> wordsToSearchList, String wholeWord, String caseSensitive, String previousLn, String displayCd) throws Exception {
	projectName =indexDirectory.substring( indexDirectory.lastIndexOf("\\")+1,indexDirectory.length());
	isWholeWord = false;
	isCaseSensitive = false;
	needPreviousLine = false;
	codeNeeded = false;
	if(null != wholeWord) {
		isWholeWord = true;
	}
	if(null != caseSensitive) {
		isCaseSensitive = true;
	}
	if(null != previousLn) {
		needPreviousLine = true;
	}
	if(null != displayCd) {
		codeNeeded = true;
	}	
	File outputFile = null;
	if(wordsToSearchList.size() > 1) {
		outputFile = new File(Constants.getOutputFolder() + "\\ListOfWords.xlsx");
	}else {
		outputFile = new File(Constants.getOutputFolder() + "\\"+ wordsToSearchList.get(0) + ".xlsx");	
	}	
	XSSFWorkbook workbook = new XSSFWorkbook();
		
	int hits = 2147483647;
	File indexDir = new File(indexDirectory);

	for (String word : wordsToSearchList) {
		System.out.println("word "+word);
		if(null == word || word.equals("")) {
			continue;
		}
		String sheetName = CodeScannerUtility.createWorkSheet(word, workbook);
		List<String> cellValues = new ArrayList<String>();	
		cellValues.add("Module");
		cellValues.add("File Name");
		cellValues.add("Word");
		cellValues.add("Line Number");
		cellValues.add("Code");
		CodeScannerUtility.writeRowData(cellValues, "heading", workbook, sheetName);	
		searchIndex(indexDir, word, hits, workbook, sheetName);

	}
	try (FileOutputStream outputStream = new FileOutputStream(outputFile)) {
        workbook.write(outputStream);
    }
System.out.println("Done");
}	

private static int searchIndex(File indexDir, String queryStr, int maxHits, XSSFWorkbook workbook, String sheet)
		throws Exception {

	int fileCount = 0;
	Directory directory = FSDirectory.open(indexDir);
	@SuppressWarnings("deprecation")
	IndexSearcher searcher = new IndexSearcher(directory);
	@SuppressWarnings("deprecation")
	QueryParser parser = new QueryParser(Version.LUCENE_35, "contents", new SimpleAnalyzer());
	
	Query query = parser.parse(CodeScannerUtility.escapeSpecialCharacters(queryStr));
	TopDocs topDocs = searcher.search(query, maxHits);

	ScoreDoc[] hits = topDocs.scoreDocs;
	for (int i = 0; i < hits.length; i++) {
		int docId = hits[i].doc;
		Document d = searcher.doc(docId);
		fileCount += getLineAndLineNumber(d.get("filename"), queryStr, workbook, sheet);
	}
	return fileCount;

}

private static int getLineAndLineNumber(String filePath, String query, XSSFWorkbook workbook, String sheet)
		throws FileNotFoundException {
	int fileCount = 0;
	boolean done = false;
	try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {

		String buffer = "";
		String currentLine;
		int lineNum = 0;
		String previousLine = "";
		String tempCurrentLine = "";
		String tempQuery = "";

		while ((currentLine = br.readLine()) != null) {
			lineNum++;
			if(!isCaseSensitive) {
				tempCurrentLine = currentLine.toLowerCase();
				tempQuery = query.toLowerCase();
			}
			else {
				tempCurrentLine = currentLine;
				tempQuery = query;
			}
			if(isWholeWord) {
				if (tempCurrentLine.matches(".*\\b" + tempQuery + "\\b.*") && tempCurrentLine.length() < 32767) {
					buffer = tempCurrentLine;
				} else {
					buffer = "";
					previousLine = tempCurrentLine;
				}
				
			}
			else {
				 if(tempCurrentLine.contains(tempQuery)&& tempCurrentLine.length() < 32767){ 
					buffer = tempCurrentLine;
				} else {
					buffer = "";
					previousLine = tempCurrentLine;
				}
			}

			if ((buffer.contains(tempQuery))) {
				String project = "";
				String fileName = "";
				project = filePath.substring(filePath.indexOf(projectName), filePath.length());
				project = project.substring(project.indexOf("\\") + 1, project.length());
				project = project.substring(0, project.indexOf("\\"));
				fileName = filePath.substring(filePath.lastIndexOf("\\") + 1, filePath.length());
				if (needPreviousLine) {
					List<String> cellValues = new ArrayList<String>();
					cellValues.add(project);
					cellValues.add(fileName);
					cellValues.add(query);
					cellValues.add((lineNum - 1) + "");
					cellValues.add("Previous Line : " + previousLine);
					CodeScannerUtility.writeRowData(cellValues, "rows", workbook, sheet);
				}
				List<String> cellValues = new ArrayList<String>();
				cellValues.add(project);
				cellValues.add(fileName);
				cellValues.add(query);
				cellValues.add(lineNum + "");
				if (needPreviousLine) {
					cellValues.add("Current Line : " + currentLine);
				} else {
					cellValues.add(currentLine);
				}
				CodeScannerUtility.writeRowData(cellValues, "rows", workbook, sheet);
				done = true;
			}
			
			  if(!codeNeeded && done) { 
				  break; 
				  }
			 
		}
	} catch (IOException e) {
		e.printStackTrace();
	}
	return fileCount;

}
public static ArrayList<String> readExcel(MultipartFile excelFile) throws IOException {
	try {
	ArrayList<String> wordsToSearchList = new ArrayList<String>();
	XSSFWorkbook wb = new XSSFWorkbook(excelFile.getInputStream());

	XSSFSheet sheet = wb.getSheetAt(0);
	XSSFRow row;
	String desc="";
	Iterator<Row> rows = sheet.rowIterator();

	while (rows.hasNext()) {
		row = (XSSFRow) rows.next();		
				 desc= row.getCell(0).getStringCellValue();
			    if(desc.contains("_")) {
				 desc= convertToTitleCaseIteratingChars(desc);
				 desc = desc.replace("_", "")	;	
				 desc = desc+"Cargo";
							 wordsToSearchList.add(desc); 
			    }else {
			    	wordsToSearchList.add(desc); 
			    }
		}
	System.out.println("wordsToSearchList.size : "+wordsToSearchList.size());
	return wordsToSearchList;
	}catch(Exception e) {
		return new ArrayList<String>();
	}
	
}

 public static String convertToTitleCaseIteratingChars(String text) {
    if (text == null || text.isEmpty()) {
        return text;
    }
 
    StringBuilder converted = new StringBuilder();
 
    boolean convertNext = true;
    for (char ch : text.toCharArray()) {
        if (ch == '_') {
            convertNext = true;
        } else if (convertNext) {
            ch = Character.toTitleCase(ch);
            convertNext = false;
        } else {
            ch = Character.toLowerCase(ch);
        }
        converted.append(ch);
    }
 
    return converted.toString();
}	

}
