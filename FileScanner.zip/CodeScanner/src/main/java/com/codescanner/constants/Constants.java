package com.codescanner.constants;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ResourceBundle;

import com.codescanner.Impl.SearchWordImplementation;

public class Constants {
	private static ResourceBundle rb = null;
	static {
		try {
			System.out.println("CodeScanner -- Attempt to Kill existing server process");
			kill();
			System.out.println("CodeScanner -- Existing server process killed succesfully");
			rb = ResourceBundle.getBundle("application");
			System.out.println("CodeScanner -- All the application properties are loaded");
			makeOutputDirectory();
			String envs = Constants.getProperties().getString("ENV_LIST");
			String[] envList = envs.split(",");
			if (null != envList && envList.length > 0) {
				for (String env : envList) {
					if (isIndexingNeeded(env)) {
						try {
							System.out.println("CodeScanner -- "+env+" Files Indexing Started");
							new SearchWordImplementation().indexFiles(Constants.getCodeFolder(env),
									Constants.getEnvProperty(env));			
							System.out.println("CodeScanner -- "+env+" Files Indexing Completed");
						} catch (Exception e) {
							System.out.println("Error -- " + e.getMessage());
							System.exit(0);
						}
					}
				}
			} else {
				System.out.println("Error -- No Environments added in application.properties file");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static ResourceBundle getProperties() {
		return rb;
	}

	public static String getEnvProperty(String env) {
		return System.getProperty("user.home") + "\\CodeScanner\\Indexer\\" + env;
	}

	public static String getCodeFolder(String env) {
		return Constants.getProperties().getString(env + "_LOC");
	}

	public static String getOutputFolder() {
		return System.getProperty("user.home") + "\\CodeScanner\\OutputFiles\\";
	}

	public static void makeOutputDirectory() {

		File file = new File(Constants.getOutputFolder());

		boolean dirCreated = file.mkdir();
		System.out.println("CodeScanner -- Folder which stores output files is created");
	}

	public static boolean isIndexingNeeded(String env) throws IOException, InterruptedException {
		String index = null;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Do you want to index code for " + env + " ?(Y/N)");
		index = br.readLine();
		if ("Y".equalsIgnoreCase(index)) {
			return true;
		} else if ("N".equalsIgnoreCase(index)) {
			return false;
		} else {
			System.out.println("Invalid option selected");
			return isIndexingNeeded(env);
		}
	}

	public static void kill() throws InterruptedException {
		try {/*
				 * taskkill /F /PID 1242
				 */
			String PID = "";
			StringBuilder pid = new StringBuilder();
			Process p = Runtime.getRuntime().exec("cmd /c netstat -aon | findstr :9010");
			p.waitFor();
			String line;
			BufferedReader error = new BufferedReader(new InputStreamReader(p.getErrorStream()));
			while ((line = error.readLine()) != null) {
				// System.out.println(line);
			}
			error.close();

			BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
			while ((line = input.readLine()) != null) {
				PID = PID + line;
			}

			for (int i = PID.length() - 1; i > 0; i--) {
				pid.append(PID.charAt(i));
				if (PID.charAt(i) == ' ') {
					break;
				}
			}
			pid = pid.reverse();
			System.out.println("CodeScanner -- Killing process running on PID : " + pid.toString());
			Process kill = Runtime.getRuntime().exec("cmd /c taskkill /F /PID " + pid.toString());
			input.close();
			OutputStream outputStream = p.getOutputStream();
			PrintStream printStream = new PrintStream(outputStream);
			printStream.println();
			printStream.flush();
			printStream.close();
		} catch (IOException ioe) {
			System.out.println("CodeScanner -- Failed to kill existing process");
		}
	}
}
